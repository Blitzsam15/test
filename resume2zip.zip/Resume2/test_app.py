"""Focused tests for the appointment booking workflow."""

from datetime import date, datetime, time, timedelta

import pytest

from app import Booking, create_app, db, get_available_slots


@pytest.fixture()
def app():
    """Use a fresh in-memory database for each test."""
    test_app = create_app(
        {
            "TESTING": True,
            "SECRET_KEY": "test-secret",
            "OWNER_PASSWORD": "test-owner-password",
            "SQLALCHEMY_DATABASE_URI": "sqlite://",
        }
    )
    yield test_app
    with test_app.app_context():
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


def csrf_token(client, path="/"):
    """Fetch a page so the session receives its form token."""
    response = client.get(path)
    assert response.status_code == 200
    with client.session_transaction() as browser_session:
        return browser_session["csrf_token"]


def next_weekday():
    """Choose a weekday in the future so all business hours are available."""
    selected = date.today() + timedelta(days=1)
    while selected.weekday() >= 5:
        selected += timedelta(days=1)
    return selected


def test_booking_is_saved_and_slot_disappears(client, app):
    selected = next_weekday()
    token = csrf_token(client)
    response = client.post(
        "/book",
        data={
            "csrf_token": token,
            "date": selected.isoformat(),
            "name": "Alex Customer",
            "email": "alex@example.com",
            "time": "09:00",
        },
    )

    assert response.status_code == 200
    assert b"YOU'RE BOOKED" in response.data
    with app.app_context():
        booking = db.session.scalar(db.select(Booking))
        assert booking.customer_name == "Alex Customer"
        assert booking.starts_at == datetime.combine(selected, time(9))
        assert datetime.combine(selected, time(9)) not in get_available_slots(selected)


def test_invalid_slot_is_not_saved(client, app):
    selected = next_weekday()
    response = client.post(
        "/book",
        data={
            "csrf_token": csrf_token(client),
            "date": selected.isoformat(),
            "name": "Alex Customer",
            "email": "alex@example.com",
            "time": "23:59",
        },
        follow_redirects=True,
    )

    assert response.status_code == 200
    assert b"not available" in response.data
    with app.app_context():
        assert db.session.scalar(db.select(db.func.count()).select_from(Booking)) == 0


def test_owner_page_requires_login_and_shows_bookings_after_login(client):
    response = client.get("/owner/bookings")
    assert response.status_code == 302
    assert "/owner/login" in response.headers["Location"]

    selected = next_weekday()
    client.post(
        "/book",
        data={
            "csrf_token": csrf_token(client),
            "date": selected.isoformat(),
            "name": "Alex Customer",
            "email": "alex@example.com",
            "time": "09:00",
        },
    )
    token = csrf_token(client, "/owner/login")
    response = client.post(
        "/owner/login",
        data={"csrf_token": token, "password": "test-owner-password"},
        follow_redirects=True,
    )

    assert response.status_code == 200
    assert b"Alex Customer" in response.data
    assert b"alex@example.com" in response.data


def test_csrf_token_is_required(client):
    response = client.post(
        "/book",
        data={
            "date": next_weekday().isoformat(),
            "name": "Alex Customer",
            "email": "alex@example.com",
            "time": "09:00",
        },
    )
    assert response.status_code == 400
