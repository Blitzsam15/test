"""A small appointment-booking app built with Flask and SQLite."""

import hmac
import os
import secrets
from datetime import date, datetime, time, timedelta
from functools import wraps

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError

db = SQLAlchemy()

# The business is open Monday to Friday, from 9:00 to 17:00.
# Change these values to match the business's schedule.
OPENING_TIME = time(9, 0)
CLOSING_TIME = time(17, 0)
SLOT_MINUTES = 30


class Booking(db.Model):
    """One appointment, with a unique start time to prevent double booking."""

    id = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(254), nullable=False)
    starts_at = db.Column(db.DateTime, nullable=False, unique=True, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.now)


def create_app(test_config=None):
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-me"),
        SQLALCHEMY_DATABASE_URI="sqlite:///bookings.db",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        OWNER_PASSWORD=os.environ.get("OWNER_PASSWORD"),
    )
    if test_config:
        app.config.update(test_config)

    db.init_app(app)
    with app.app_context():
        db.create_all()

    @app.context_processor
    def provide_csrf_token():
        """Make a session token available to every HTML form."""
        return {"csrf_token": csrf_token}

    @app.get("/")
    def index():
        """Show the available appointments for the selected date."""
        selected_date = parse_selected_date(request.args.get("date"))
        slots = get_available_slots(selected_date)
        return render_template("index.html", selected_date=selected_date, slots=slots)

    @app.post("/book")
    def book():
        """Validate a submitted slot and save the customer's booking."""
        validate_csrf_token()
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        selected_date = parse_selected_date(request.form.get("date"))
        selected_time = request.form.get("time", "")

        if not name or len(name) > 100:
            flash("Enter your name (up to 100 characters).", "error")
            return redirect(url_for("index", date=selected_date.isoformat()))
        if not email or len(email) > 254 or "@" not in email:
            flash("Enter a valid email address.", "error")
            return redirect(url_for("index", date=selected_date.isoformat()))

        valid_times = {slot.strftime("%H:%M") for slot in get_available_slots(selected_date)}
        if selected_time not in valid_times:
            flash("That time is not available. Please choose another slot.", "error")
            return redirect(url_for("index", date=selected_date.isoformat()))

        starts_at = datetime.combine(
            selected_date, time.fromisoformat(selected_time)
        )
        booking = Booking(
            customer_name=name,
            email=email,
            starts_at=starts_at,
        )
        db.session.add(booking)
        try:
            db.session.commit()
        except IntegrityError:
            # The database uniqueness rule also protects against simultaneous requests.
            db.session.rollback()
            flash("That time was just booked. Please choose another slot.", "error")
            return redirect(url_for("index", date=selected_date.isoformat()))

        return render_template("confirmation.html", booking=booking)

    @app.route("/owner/login", methods=["GET", "POST"])
    def owner_login():
        """Authenticate the business owner before showing private bookings."""
        if request.method == "POST":
            validate_csrf_token()
            configured_password = app.config.get("OWNER_PASSWORD")
            submitted_password = request.form.get("password", "")
            if configured_password and hmac.compare_digest(
                submitted_password, configured_password
            ):
                session["is_owner"] = True
                return redirect(url_for("owner_bookings"))
            flash("Owner access is not configured or the password is incorrect.", "error")
        return render_template("owner_login.html")

    @app.get("/owner/bookings")
    @owner_required
    def owner_bookings():
        """List all bookings in chronological order for the owner."""
        bookings = db.session.scalars(
            db.select(Booking).order_by(Booking.starts_at)
        ).all()
        return render_template("owner_bookings.html", bookings=bookings)

    @app.post("/owner/logout")
    @owner_required
    def owner_logout():
        """End the owner's session."""
        validate_csrf_token()
        session.pop("is_owner", None)
        flash("You have been signed out.", "success")
        return redirect(url_for("owner_login"))

    return app


def owner_required(view):
    """Restrict a view to an authenticated owner session."""
    @wraps(view)
    def wrapped_view(**kwargs):
        if not session.get("is_owner"):
            return redirect(url_for("owner_login"))
        return view(**kwargs)

    return wrapped_view


def csrf_token():
    """Return a per-session token used to protect forms from cross-site posts."""
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def validate_csrf_token():
    """Reject form submissions without the token issued to this browser session."""
    submitted_token = request.form.get("csrf_token", "")
    expected_token = session.get("csrf_token", "")
    if not expected_token or not hmac.compare_digest(submitted_token, expected_token):
        abort(400, description="The form expired or could not be verified. Please reload.")


def parse_selected_date(value):
    """Read a requested date, falling back to today if it is missing or invalid."""
    try:
        return date.fromisoformat(value) if value else date.today()
    except ValueError:
        return date.today()


def get_available_slots(selected_date):
    """Return future, unbooked slot start times for one weekday."""
    if selected_date.weekday() >= 5:
        return []

    now = datetime.now()
    slot_length = timedelta(minutes=SLOT_MINUTES)
    current = datetime.combine(selected_date, OPENING_TIME)
    closing = datetime.combine(selected_date, CLOSING_TIME)
    booked_times = set(
        db.session.scalars(
            db.select(Booking.starts_at).where(
                Booking.starts_at >= current,
                Booking.starts_at < closing,
            )
        ).all()
    )

    slots = []
    while current + slot_length <= closing:
        if current > now and current not in booked_times:
            slots.append(current)
        current += slot_length
    return slots


if __name__ == "__main__":
    # Debug mode is convenient locally; turn it off for a real deployment.
    create_app().run(debug=True)
