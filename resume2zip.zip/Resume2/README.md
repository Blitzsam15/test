# Brightday appointment booking

A small Flask app where customers can book an available appointment and the
business owner can review all bookings.

## Run locally

1. Create and activate a virtual environment.
2. Install dependencies with `pip install -r requirements.txt`.
3. Set an owner password and a private Flask secret key:

   ```powershell
   $env:OWNER_PASSWORD = "choose-a-strong-password"
   $env:SECRET_KEY = "replace-with-a-long-random-secret"
   ```

4. Start the app with `python app.py`, then open
   [http://127.0.0.1:5000](http://127.0.0.1:5000).

SQLite creates `instance/bookings.db` the first time the app starts. The owner
signs in at `/owner/login`; all appointment details are private behind that
login.

## Customize the schedule

Edit `OPENING_TIME`, `CLOSING_TIME`, and `SLOT_MINUTES` near the top of
`app.py`. The starter schedule is Monday to Friday, 9:00 AM to 5:00 PM, in
30-minute appointments. Times use the server's local timezone.

## Before deploying

Set strong, private `SECRET_KEY` and `OWNER_PASSWORD` environment variables and
serve the app behind a production WSGI server over HTTPS. The built-in Flask
development server and debug mode are for local development only. Add proper
email confirmation and a production-ready authentication/rate-limiting
strategy if the booking site will be exposed publicly.
